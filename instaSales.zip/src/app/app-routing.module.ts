import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from './component/login-component/login.component';
import { RegisterComponent } from './component/register-component/register.component';
import { HomeComponent } from './component/home-component/home.component';
import { DashComponent } from './component/dashboard-component/dash.component';
import { Lmscomponent } from './component/lms-component/lms.component';
import {AuthGuard} from './guards/auth.guard'
import { from } from 'rxjs';
const routes: Routes = [
   
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  },
  {
    path:'dash',
    component:DashComponent,
    // canActivate: [AuthGuard]
  },
  {
    path:'lms',
    component:Lmscomponent,
    // canActivate: [AuthGuard]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
