import { Component } from '@angular/core';
import { ActivatedRoute, Router, Routes, RouterModule } from '@angular/router';
@Component({
  selector: 'header-component',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  title = 'instasales';
  constructor(
    private route: ActivatedRoute,
    private router: Router) {
  }
  get getLoginFlag() {

    const currentUser = sessionStorage.getItem("currentUser");     
    if (currentUser) { 
    return true;
    }
    return false;
  }
  logout() {
    sessionStorage.removeItem('currentUser');
    this.router.navigate(['/home']);
  }
}
