import { Component } from '@angular/core';

@Component({
  selector: 'lms-component',
  templateUrl: './lms.component.html',
  styleUrls: ['./lms.component.scss']
})
export class Lmscomponent {
  title = 'instasales';
}


