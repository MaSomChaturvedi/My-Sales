import { Component, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { InstaSalesService } from 'src/app/services/insta-sales-service';
import {Item} from '../../model/item'
import {ITEMS} from '../../model/emptype'
import { LOGIN } from 'src/app/model/login';

import { from } from 'rxjs';
import { USER } from 'src/app/model/user';

@Component({
  selector: 'register-component',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
@Injectable({ providedIn: 'root' })
export class RegisterComponent {
  title = 'instasales';
  public agent: string;
  public agency: string;
  public company: string;
  public userName: string = ""
  public password: string = ""
  public Name: string = ""
  public Number: string = ""
  public email: string = ""
  public DOB: string = ""
  public Address: string = ""
  public Pin: string = ""
  public State: string = ""
  public Code: string = ""
  public Nominee: string = ""
  public Relation: string = ""
  public Age: string = ""
  public error: string = ""
  itemsList: Item[] = ITEMS;
  public comboSelected:string="Agent";
  public showAgent:boolean = false;
  public showAgency:boolean = false;
  public showCompany:boolean = false;
  public login:LOGIN;
  public user:USER;
  public agentPhoto:File=null;
  public agentPanCard:File=null;
  public agentAddressProf1:File=null;
  public agentAddressProf2:File=null;
  public agencyPhoto:File=null;
  public agencyPanCard:File=null;
  public agencyAddressProf1:File=null;
  public agencyAddressProf2:File=null;
  public companyGst:File=null;
  public companyCoi:File=null;
  constructor(private router: Router, private instaSalesService: InstaSalesService) {
    this.itemsList = ITEMS;
    this.comboSelected = "Agent";
    this.showAgent=true;
    this.login = new LOGIN();
    this.user=new USER();
  }
  public showDiv(){
    if(this.comboSelected=='Agent'){
      this.showAgent=true;
      this.showAgency=false;
      this.showCompany=false;
    }else if(this.comboSelected=='Agency'){
      this.showAgent=false;
      this.showAgency=true;
      this.showCompany=false;
    }
    else if(this.comboSelected=='Company'){
      this.showAgent=false;
      this.showAgency=false;
      this.showCompany=true;
    }
  }
  public getrotp(login?){
   debugger
   this.login = new LOGIN(this.user);
    this.instaSalesService.getrotp(this.login).subscribe(data=>{        
        if( data.status == 200)
        this.error='OTP is send over your e-mail"'
        if( data.status == 208)
        this.error='OTP is already send over your e-mail'       
      
    })
  }
  public onSubmit() {
    

    
    this.instaSalesService.isValidUser(this.userName, this.password).subscribe(data => {
      sessionStorage.setItem('currentUser', JSON.stringify(this.userName));
      const route = '/login'
      this.router.navigate([route]);
    },
      error => {
        this.error = "Problem in login";

        const route = '/register'
        this.router.navigate([route]);
      });
  } 
  selectAgentFile(files: FileList) {
    this.agentPhoto = files.item(0);
  }
  selectAgentPanCard(files: FileList) {
    this.agentPanCard = files.item(0);
  }
  selectAgentAddressProof1(files: FileList) {
    this.agentAddressProf1 = files.item(0);
  }
  selectAgentAddressProof2(files: FileList) {
    this.agentAddressProf2 = files.item(0);
  }
  selectAgencyFile(files: FileList) {
    this.agencyPhoto = files.item(0);
  }
  selectAgencyPanCard(files: FileList) {
    this.agencyPanCard = files.item(0);
  }
  selectAgencyAddressProof1(files: FileList) {
    this.agencyAddressProf1 = files.item(0);
  }
  selectAgencyAddressProof2(files: FileList) {
    this.agencyAddressProf2 = files.item(0);
  }
  selectCompanyGst(files: FileList) {
    this.companyGst = files.item(0);
  }
  selectCompanyCoi(files: FileList) {
    this.companyCoi = files.item(0);
  }
  
  public Register(KYCDocuments){
    debugger
    if(this.user.token!=this.user.confirmPassword){
      this.error=" password mismatch"
      return;
    }
    
    this.instaSalesService.register(KYCDocuments).subscribe((data)=>{
              //this.router.navigateByUrl('/index')
              
              this.user.token = null;
             
              localStorage.setItem('USER', JSON.stringify ( KYCDocuments.value));
              this.user = KYCDocuments.value;
              this.login.email = this.user.email;
              localStorage.setItem(this.user.email,  this.user.image);
              this.user = new USER();

            })
          
            
  }


}

