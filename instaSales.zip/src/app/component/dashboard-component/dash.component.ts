import { Component } from '@angular/core';

@Component({
  selector: 'dash-component',
  templateUrl: './dash.component.html',
  styleUrls: ['./dash.component.scss']
})
export class DashComponent {
  title = 'instasales';
}
