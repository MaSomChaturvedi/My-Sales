import { Component, OnInit, Input, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { InstaSalesService } from 'src/app/services/insta-sales-service';
import { LOGIN } from 'src/app/model/login';

@Component({
  selector: 'login-component',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
@Injectable({ providedIn: 'root' })
export class LoginComponent {
  title = 'instasales';
  public userName: string = ""
  public password: string = ""
  public mobile: string = ""
  public otp: string = ""
  public error:string=""
  public login:LOGIN;
  
  constructor(private router:Router,private instaSalesService:InstaSalesService){
    this.login = new LOGIN();
  }
  public getlotp(login?){
   
    this.instaSalesService.getlotp(this.login).subscribe(data=>{
      
        
        if( data.status == 200)
        this.error='OTP is send over your e-mail"'
        if( data.status == 208)
        this.error='OTP is already send over your e-mail'       
      
    })
  }
  public  loginPage(login, event?){ 
    debugger;
   

    this.instaSalesService.login( this.login ).subscribe(data => {
      console.log(data);
      sessionStorage.setItem('currentUser', data);
      const route = '/dash'
      this.router.navigate([route]);
    },
    error => {
      this.error = "Problem in login, username or password is wrong";
      this.userName=""
      this.password=""
      const route = '/login'
      this.router.navigate([route]);
    });
  }

}

