import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import {environment} from '../../environments/environment';
import { LOGIN } from '../model/login';
@Injectable({ providedIn: 'root' })
export class InstaSalesService
 {
    private subject = new Subject<any>();
    public dataFile: string;
    public fileLocation: string;
    public dataFileLocation: string;
    fileGridSectionFilterData: any;
    body:any;
  
    public instaSalesHostName: string = environment.instaurl;
    public instaSalesLoginHostName: string = environment.loginurl;
  
    constructor(private httpClient: HttpClient) { }
    loadData() {
        this.subject.next();
    }
    getData(): Observable<any> {
        return this.subject.asObservable();
    }
    public getlotp(login:LOGIN){          
        return this.httpClient.post( this.instaSalesHostName+'/getlotp', {'email': login.email} ,{ observe: 'response'});
      }
      public getrotp(login:LOGIN){          
        return this.httpClient.post( this.instaSalesHostName+'/getrotp', {'email': login.email} ,{ observe: 'response'});
      }
    public login(login:LOGIN){
        
        let headers = new HttpHeaders();
        let formdata: FormData = new FormData();
        const options = {
            headers: headers,         
        }        
       
        return this.httpClient.post(this.instaSalesLoginHostName + "/login", login, {responseType: 'text'});
    }
    public register(KYCDocuments){          
        return this.httpClient.post( this.instaSalesHostName+'/register', KYCDocuments.value ,{ observe: 'response'});
      }
    public getDomains() {
        return this.httpClient.get(this.instaSalesHostName + "/getAllDomain");
    }
    public getDropDown(fileLocation:string) {
        return this.httpClient.get(this.instaSalesHostName + "/fetchAllFilesTypes?fileLocationType="+fileLocation);
    }
   
    public getFilterDropDownValues(dataFile: string, fileLocation: string) {
        this.dataFile = dataFile;
        this.fileLocation = fileLocation;
        return this.httpClient.get(this.instaSalesHostName + "/fetchFileInformation?fileType=" + this.dataFile + "&fileLocationType=" + this.fileLocation);
    }
    public getFileGridSectionHeaderAndData(fileGridSectionFilterData: Object) {
        this.fileGridSectionFilterData = fileGridSectionFilterData;
        let headers = new HttpHeaders();     
        headers = headers.set("selectDataFile", fileGridSectionFilterData["dataFile"]);
        headers = headers.set("datafile", fileGridSectionFilterData["filePath"]);
        headers = headers.set("fileType", fileGridSectionFilterData["fileType"]);
        headers = headers.set("region", fileGridSectionFilterData["region"]);
        headers = headers.set("fileExt", fileGridSectionFilterData["fileExtension"]);
        headers = headers.set("includeZip", fileGridSectionFilterData["includeZip"]);
        headers = headers.set("fileLocationType", fileGridSectionFilterData["fileLocation"]);
        headers = headers.set("fileDate", fileGridSectionFilterData["filterDate"]);
        return this.httpClient.get(this.instaSalesHostName + "/fetchFileFromDirectory", { headers: headers });
    }
    public getFileDetailsGridSectionHeaderAndData(fileDetailGridSectionFilterData: any) {
        this.fileGridSectionFilterData["fileName"] = fileDetailGridSectionFilterData["filename"];
        let headers = new HttpHeaders();
        headers = headers.set("selectDataFile", this.fileGridSectionFilterData["dataFile"]);
        headers = headers.set("datafile", this.fileGridSectionFilterData["filePath"]);
        headers = headers.set("fileType", this.fileGridSectionFilterData["fileType"]);
        headers = headers.set("fileLocationType", this.fileGridSectionFilterData["fileLocation"]);
        headers = headers.set("fileDate", this.fileGridSectionFilterData["filterDate"]);
        headers = headers.set("recordCount", this.fileGridSectionFilterData["recordCount"]);
        headers = headers.set("fileName", fileDetailGridSectionFilterData["filename"]);

        return this.httpClient.get(this.instaSalesHostName + "/fetchRecords", { headers: headers });

    }
    public downloadRawFile(){        
        let headers = new HttpHeaders("");
        headers = headers.set("Content-Type","application/text");
        headers = headers.set("datafile", this.fileGridSectionFilterData["filePath"]);
        headers = headers.set("fileName", this.fileGridSectionFilterData["fileName"]);
        
       
        return this.httpClient.post(this.instaSalesHostName + "/downloadRawFile",this.body ,  {headers: headers , responseType:'text'});
    }
    public searchFileDetailsGridSectionHeaderAndData(fileDetailGridSectionFilterData: any) {
        let headers = new HttpHeaders();
        let formdata: FormData = new FormData();
        formdata.append('file', fileDetailGridSectionFilterData["file"]);
        console.log(fileDetailGridSectionFilterData["file"])
        headers = headers.set("selectDataFile", this.fileGridSectionFilterData["dataFile"]);
        headers = headers.set("datafile", this.fileGridSectionFilterData["filePath"]);
        headers = headers.set("fileType", this.fileGridSectionFilterData["fileType"]);
        headers = headers.set("fileLocationType", this.fileGridSectionFilterData["fileLocation"]);
        headers = headers.set("fileDate", this.fileGridSectionFilterData["filterDate"]);
        headers = headers.set("recordCount", this.fileGridSectionFilterData["recordCount"]);
        headers = headers.set("fileName", this.fileGridSectionFilterData["fileName"]);
        headers = headers.set("columnIndex", fileDetailGridSectionFilterData["columnIndex"]);
        headers = headers.set("columnValue", fileDetailGridSectionFilterData["searchValue"]);
        headers = headers.set("columnName", fileDetailGridSectionFilterData["columnName"]);
        const options = {
            headers: headers,         
        }        
        return this.httpClient.post(this.instaSalesHostName + "/searchRecord", formdata, options);

    }
    /******* insta sales */
    public isValidUser(userName:string,password:string){
        let headers = new HttpHeaders();
       
        headers = headers.set("userName", userName);
        headers = headers.set("password", password);
       
      
        const options = {
            headers: headers,         
        }        
       
        return this.httpClient.post(this.instaSalesHostName + "getAutherizedUser", null, options);
    }
   

}