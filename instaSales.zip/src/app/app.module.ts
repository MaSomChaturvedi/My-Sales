import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from  '@angular/common/http';
import { HttpClientXsrfModule } from  '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login-component/login.component';
import { RegisterComponent } from './component/register-component/register.component';
import { HeaderComponent } from './component/header-component/header.component';
import { HomeComponent } from './component/home-component/home.component';
import { DashComponent } from './component/dashboard-component/dash.component';
import { Lmscomponent } from './component/lms-component/lms.component';
import { PathLocationStrategy,LocationStrategy } from '@angular/common';
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HeaderComponent,
    HomeComponent,
    DashComponent,
    Lmscomponent
    ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
   
    NgbModule,
    HttpClientModule,

    HttpClientXsrfModule.withOptions({
      cookieName: 'My-Xsrf-Cookie',
      headerName: 'My-Xsrf-Header',
    }),
  ],
  providers: [DatePipe,{provide: LocationStrategy, useClass: PathLocationStrategy}],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
