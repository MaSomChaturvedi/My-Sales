export class USER{
    public name:string = null;
    public email:string = null;
    public mobile:string = null;
    public token:string = null;
    public empId:string =null;
    public id:string = null; 
    public image:string;
    public dob:string =null;
    public state:string =null;
    public nominee:string =null;
    public relation:string =null;
    public age:string =null;
    public pin:string =null;
    public address:string =null;
    public password:string=null;
    public confirmPassword:string=null;
   
  }