export class LOGIN{
    public email:string = null;
    public mobile:string = null;
    public otp:string = null;
    public token:string = null;
    public dob:string =null;
    public state:string =null;
    public nominee:string =null;
    public relation:string =null;
    public age:string =null;
    public pin:string =null;
    public address:string =null;
    constructor(U?){
      if(U){this.email = U.email;}
    }
  }