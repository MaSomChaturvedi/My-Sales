export class Item{
    name:string;
    value:string;
}