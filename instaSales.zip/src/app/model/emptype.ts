import { Item } from './item';

export const ITEMS: Item[] = [
    {
        name:'Agent',
        value:'Agent'
     },
     {
         name:'Agency',
         value:'Agency'
      },
      {
          name:'Company',
          value:'Company'
       }
];
