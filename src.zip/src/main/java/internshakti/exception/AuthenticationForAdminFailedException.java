package internshakti.exception;

import java.util.Date;

public class AuthenticationForAdminFailedException extends RuntimeException {

	private String otp;
	private String suppliedOTP;
	private Date otpgeneratedTime;

	@Override
	public String toString() {
		return "AuthenticationForAdminFailedException [otp=" + otp + ", suppliedOTP=" + suppliedOTP
				+ ", otpgeneratedTime=" + otpgeneratedTime + "]";
	}

	public AuthenticationForAdminFailedException(String otp, String suppliedOTP, Date otpgeneratedTime) {
		super();
		this.otp = otp;
		this.suppliedOTP = suppliedOTP;
		this.otpgeneratedTime = otpgeneratedTime;
	}

}
