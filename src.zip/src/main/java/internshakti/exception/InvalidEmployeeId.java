package internshakti.exception;

public class InvalidEmployeeId extends Exception{
	private String empId;

	public InvalidEmployeeId(String empId) {
		super();
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "InvalidEmployeeId [empId=" + empId + "]";
	}
	
}
