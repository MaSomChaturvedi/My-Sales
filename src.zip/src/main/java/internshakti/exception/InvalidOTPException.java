package internshakti.exception;

public class InvalidOTPException extends Exception {

}
