package internshakti.exception;

public class UserExistException extends Exception {
	private String email;
	private String mobile;
	public UserExistException(String email, String mobile) {
		super();
		this.email = email;
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "UserExistException [email=" + email + ", mobile=" + mobile + "]";
	}
}
