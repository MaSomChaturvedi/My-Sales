package internshakti.service.mail;

import java.io.File;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.ApplicationVisitor;

@Service
public class GmailMailSender {
	private static final Logger LOGGER = LoggerFactory.getLogger(GmailMailSender.class);
	@Autowired
	private JavaMailSender sender;

	public void sendOTP(ApplicationUser applicationUser) {
		String text = "Here is your OTP: " + applicationUser.getOtp();
		String subject = "Internshakti: OTP";
		sendSimpleMessage(applicationUser.getEmail(), subject, text);
	}

	public void sendOTP(ApplicationVisitor applicationVisitor) {
		String text = "Here is your OTP: " + applicationVisitor.getOtp();
		String subject = "Internshakti: OTP";
		sendSimpleMessage(applicationVisitor.getEmail(), subject, text);
	}
	
	private void sendSimpleMessage(String to, String subject, String text) {
		LOGGER.debug("Start sending mail started");
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(to);
		message.setSubject(subject);
		message.setText(text);
		sender.send(message);
		LOGGER.debug("Start sending mail finished");
	}

	private void sendMessageWithAttachment(String to, String subject, String text, String pathToAttachment,
			String attachmentName) throws MessagingException {
		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message, true);
		helper.setTo(to);
		helper.setSubject(subject);
		helper.setText(text);
		FileSystemResource file = new FileSystemResource(new File(pathToAttachment));
		helper.addAttachment(attachmentName, file);
		sender.send(message);
	}
}
