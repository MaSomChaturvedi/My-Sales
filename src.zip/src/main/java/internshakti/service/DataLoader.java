package internshakti.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dao.MasterDataRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.ApplicationUser.Role;
import internshakti.repository.mongo.dco.MasterData;

@Component
public class DataLoader implements ApplicationRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(DataLoader.class);

	@Autowired
	private MasterDataRepository masterDataRepository;

	@Autowired
	private ApplicationUserRepository applicationUserRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	public DataLoader(MasterDataRepository masterDataRepository) {
		this.masterDataRepository = masterDataRepository;
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		LOGGER.debug("Setting up master data started.");
		masterDataRepository.deleteAll();
		masterDataRepository.save(new MasterData());
		ApplicationUser rootUser = applicationUserRepository.findByEmail(rootUserEmail);
		if (rootUser == null) {
			rootUser = new ApplicationUser();
			rootUser.setEmail(rootUserEmail);
			rootUser.setMobile(rootUserMobile);
			rootUser.setName(rootUserName);
			rootUser.setToken(bCryptPasswordEncoder.encode(rootUserToken));
			rootUser.setRole(Role.ROLE_ADMIN);
			applicationUserRepository.save(rootUser);
		}
		LOGGER.debug("Setting up master data finished.");

	}

	@Value("${root.user.name}")
	private String rootUserName;
	@Value("${root.user.email}")
	private String rootUserEmail;
	@Value("${root.user.mobile}")
	private String rootUserMobile;
	@Value("${root.user.token}")
	private String rootUserToken;

}
