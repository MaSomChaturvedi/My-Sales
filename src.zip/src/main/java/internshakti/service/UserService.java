package internshakti.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import internshakti.exception.InvalidEmployeeId;
import internshakti.exception.InvalidOTPException;
import internshakti.exception.UserExistException;
import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dao.ApplicationVisitorRepository;
import internshakti.repository.mongo.dao.EmployeeDetailRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.ApplicationUser.Role;
import internshakti.repository.mongo.dco.ApplicationVisitor;
import internshakti.repository.mongo.dco.EmployeeDetail;
import internshakti.util.Utility;

@Service
public class UserService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserService.class);
	@Autowired
	private ApplicationUserRepository userRepository;
	@Autowired
	private ApplicationVisitorRepository visitorRepository;
	@Autowired
	private EmployeeDetailRepository employeeDetailRepository;
	@Value("${root.user.email}")
	private String rootUserEmail;

	public void checkUserAlreadyExist(ApplicationUser applicationUser) throws UserExistException {
		LOGGER.debug("validating user started");
		ApplicationUser user1 = userRepository.findByEmail(applicationUser.getEmail().trim());
		ApplicationUser user2 = userRepository.findByMobile(applicationUser.getMobile().trim());
		if (user1 != null && user2 != null) {
			throw new UserExistException(applicationUser.getEmail().trim(), applicationUser.getMobile().trim());
		}

		if (user1 != null) {
			throw new UserExistException(applicationUser.getEmail().trim(), "");
		}

		if (user2 != null) {
			throw new UserExistException("", applicationUser.getMobile().trim());
		}
		LOGGER.debug("validating user finished");
	}
	
	public void validateUserOTP(ApplicationUser applicationUser) throws InvalidOTPException {
		LOGGER.debug("validating otp started");
		ApplicationVisitor applicationVisitor = visitorRepository.findByEmail(applicationUser.getEmail());
		if (applicationVisitor == null || !applicationVisitor.getOtp().trim().equals(applicationUser.getOtp().trim())) {
			throw new InvalidOTPException();
		}
		LOGGER.debug("validating otp finished");
	}

	public void saveUser(ApplicationUser applicationUser) throws InvalidEmployeeId {
		if (Utility.isStringEmpty(applicationUser.getEmpId())) {
			ApplicationUser rootUser = userRepository.findByEmail(rootUserEmail);
			applicationUser.setParentUser(new ApplicationUser(rootUser.getId()));
			applicationUser.setRole(Role.ROLE_CUSTOMER);
			userRepository.save(applicationUser);
		} else {
			EmployeeDetail employeeDetail = employeeDetailRepository.findByEmpIdAndAssigned(applicationUser.getEmpId(),
					false);
			if (employeeDetail == null) {
				throw new InvalidEmployeeId(applicationUser.getEmpId());
			}
			applicationUser.setEmpId(employeeDetail.getEmpId());
			applicationUser.setParentUser(employeeDetail.getOwner());
			applicationUser.setRole(employeeDetail.getRole());
			employeeDetail.setAssigned(true);
			employeeDetail.setAssignTo(applicationUser.getEmail());
			userRepository.save(applicationUser);
			employeeDetailRepository.save(employeeDetail);
		}
	}

}
