package internshakti.util;

public class Utility {

	public static boolean isStringEmpty(String string) {
		return string == null || Constants.EMPTY.equals(string.trim());
	}
}
