package internshakti.util.jackson;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import internshakti.util.Constants;

public class DateDeserializer extends JsonDeserializer<Date> {
	private static final Logger LOGGER = LoggerFactory.getLogger(DateDeserializer.class);

	@Override
	public Date deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
		try {
			return Constants.FORMATTER.parse(p.getValueAsString());
		} catch (ParseException e) {
			LOGGER.error("Caught error while deserialzing", e);
			throw new RuntimeException("Invalid date to parse, valid format is:yyyy-MM-dd HH:mm:ssZ", e);
		}
	}
}
