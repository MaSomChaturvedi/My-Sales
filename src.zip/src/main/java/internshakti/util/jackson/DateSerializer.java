package internshakti.util.jackson;

import java.io.IOException;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

import internshakti.util.Constants;

public class DateSerializer extends JsonSerializer<Date> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(DateSerializer.class);

	@Override
	public void serialize(Date value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
		LOGGER.debug("start serializing date");
		gen.writeString(Constants.FORMATTER.format(value));
		LOGGER.debug("finish serializing date");
	}

}
