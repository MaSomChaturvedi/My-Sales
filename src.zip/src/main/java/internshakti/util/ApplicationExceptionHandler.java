package internshakti.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ApplicationExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(ApplicationExceptionHandler.class);

	@ExceptionHandler(Throwable.class)
	public ResponseEntity<?> handleException(Throwable ex) {
		LOGGER.error("Unknown error occurred", ex);
		return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).build();

	}

}