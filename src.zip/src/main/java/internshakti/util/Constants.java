package internshakti.util;

import java.text.SimpleDateFormat;

public class Constants {
	public static final String SECRET = "zgh9uqp01Jkl-+?";
	
	public static final String EMPTY = "";

	public static final long EXPIRATION_TIME = 18000000; // 5 Hrs

	public static final String TOKEN_PREFIX = "Secure ";

	public static final String HEADER_STRING = "Authorization";

	public static final String REGISTER_URL = "/internshakti/api/register";
	public static final String REGISTER_WEB_URL = "/internshakti/api/registerWeb";
	public static final String REGISTER_DETAILS = "/internshakti/api/registerDetails";
	
	public static final String LOGIN_OTP_URL = "/internshakti/api/getlotp";
	public static final String FORGET_OTP_URL = "/internshakti/api/getfotp";
	public static final String REGISTER_OTP_URL = "/internshakti/api/getrotp";
	public static final String RESET_TOKEN = "/internshakti/api/resettoken";
	public static final String EMPLOYEE_URL = "/internshakti/api/employee";
	public static final String STATICRA = "/test.html";
	public static final SimpleDateFormat FORMATTER = new SimpleDateFormat("yyyy-MM-dd");

}
