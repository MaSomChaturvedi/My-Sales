package internshakti.security;

import static internshakti.util.Constants.EMPLOYEE_URL;
import static internshakti.util.Constants.FORGET_OTP_URL;
import static internshakti.util.Constants.LOGIN_OTP_URL;
import static internshakti.util.Constants.REGISTER_OTP_URL;
import static internshakti.util.Constants.REGISTER_URL;
import static internshakti.util.Constants.REGISTER_WEB_URL;
import static internshakti.util.Constants.RESET_TOKEN;
import static internshakti.util.Constants.REGISTER_DETAILS;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import internshakti.security.jwt.JWTAuthenticationFilter;
import internshakti.security.jwt.JWTAuthorizationFilter;

@EnableWebSecurity

public class WebSecurity extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	private static final Logger LOGGER = LoggerFactory.getLogger(WebSecurity.class);

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		LOGGER.debug("configuring security started");
		http.cors().and().csrf().disable().authorizeRequests()
				.antMatchers(HttpMethod.POST, REGISTER_URL).permitAll()
				.antMatchers(HttpMethod.POST, REGISTER_WEB_URL).permitAll()
				.antMatchers(HttpMethod.POST, REGISTER_DETAILS).permitAll()
				.antMatchers(HttpMethod.POST, LOGIN_OTP_URL).permitAll()
				.antMatchers(HttpMethod.POST, FORGET_OTP_URL).permitAll()
				.antMatchers(HttpMethod.POST, REGISTER_OTP_URL).permitAll()
				.antMatchers(HttpMethod.PUT, RESET_TOKEN).permitAll()
				.antMatchers(EMPLOYEE_URL).hasRole("ADMIN")
				.antMatchers(HttpMethod.GET, internshakti.util.Constants.STATICRA).permitAll().anyRequest()
				.authenticated().and().addFilter(new JWTAuthenticationFilter(authenticationManager()))
				.addFilter(new JWTAuthorizationFilter(authenticationManager()));
		LOGGER.debug("configuring security finished");

	}

	@Override

	public void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService).passwordEncoder(bCryptPasswordEncoder);
	}

}