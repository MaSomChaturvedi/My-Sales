package internshakti.security;

import static java.util.Collections.emptyList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import internshakti.exception.AuthenticationForAdminFailedException;
import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.ApplicationUser.Role;

@Service

public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private ApplicationUserRepository userRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailsServiceImpl.class);

	@Override
	public UserDetails loadUserByUsername(String emailOrMobile) throws UsernameNotFoundException {
		LOGGER.debug("Loading user started:" + emailOrMobile);
		String otp = null;
		String userId = null;
		if (emailOrMobile.indexOf("```") != -1) {
			userId = emailOrMobile.substring(0, emailOrMobile.lastIndexOf("```"));
			otp = emailOrMobile.substring(emailOrMobile.lastIndexOf("```") + 3);

		} else {
			userId = emailOrMobile;
		}
		ApplicationUser applicationUser = userRepository.findByEmail(userId);
		if (applicationUser == null) {
			applicationUser = userRepository.findByMobile(userId);
			if (applicationUser == null) {
				throw new UsernameNotFoundException(userId);
			}
		}
		if ((Role.ROLE_ADMIN.equals(applicationUser.getRole()) && otp == null)
				|| (Role.ROLE_ADMIN.equals(applicationUser.getRole()) && applicationUser.getOtp() == null)
				|| (Role.ROLE_ADMIN.equals(applicationUser.getRole()) && !applicationUser.validOTP())
				|| (Role.ROLE_ADMIN.equals(applicationUser.getRole()) && !applicationUser.getOtp().equals(otp))) {
			throw new AuthenticationForAdminFailedException(applicationUser.getOtp(), otp,
					applicationUser.getOtpGeneratedTime());
		}
		LOGGER.debug("Loading user finished");
		return new User(applicationUser.getEmail(), applicationUser.getToken(), emptyList());

	}

}