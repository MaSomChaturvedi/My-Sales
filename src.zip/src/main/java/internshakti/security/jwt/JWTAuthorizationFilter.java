package internshakti.security.jwt;

import static internshakti.util.Constants.HEADER_STRING;
import static internshakti.util.Constants.TOKEN_PREFIX;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.context.support.WebApplicationContextUtils;

import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.util.Constants;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.SignatureException;

public class JWTAuthorizationFilter extends BasicAuthenticationFilter {
	private static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthorizationFilter.class);

	public JWTAuthorizationFilter(AuthenticationManager authManager) {
		super(authManager);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		try {
			if (isAuthorizationSkipped(req.getRequestURI())) {
				chain.doFilter(req, res);
				return;
			}
			String header = req.getHeader(HEADER_STRING);
			if (header == null || !header.startsWith(TOKEN_PREFIX)) {
				LOGGER.debug("Invalid header");
				res.setStatus(HttpStatus.UNAUTHORIZED.value());
				chain.doFilter(req, res);
				return;

			}
			UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
			SecurityContextHolder.getContext().setAuthentication(authentication);
			LOGGER.debug("Authentication successful.");
			chain.doFilter(req, res);
		} catch (ExpiredJwtException exception) {
			res.setStatus(HttpStatus.UNAUTHORIZED.value());
			exception.printStackTrace();
		} catch (SignatureException exception) {
			res.setStatus(HttpStatus.UNAUTHORIZED.value());
			exception.printStackTrace();
		}

	}
	
	private boolean isAuthorizationSkipped(String uri) {
		return uri.equalsIgnoreCase(Constants.LOGIN_OTP_URL) || uri.equalsIgnoreCase(Constants.REGISTER_URL)
				|| uri.equalsIgnoreCase(Constants.FORGET_OTP_URL) || uri.equalsIgnoreCase(Constants.RESET_TOKEN);
	}

	private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
		String token = request.getHeader(HEADER_STRING);
		String user = TokenService.validateToken(token);
		ApplicationUserRepository applicationUserRepository = getApplicationUserRepository(request.getServletContext());
		ApplicationUser applicationUser = applicationUserRepository.findByEmail(user);
		List<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(applicationUser.getRole().name()));
		return new UsernamePasswordAuthenticationToken(applicationUser, null, authorities);

	}

	private ApplicationUserRepository getApplicationUserRepository(ServletContext servletContext) {
		return WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext)
				.getBean(ApplicationUserRepository.class);
	}

}