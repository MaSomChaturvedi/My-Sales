package internshakti.security.jwt;

import static internshakti.util.Constants.EXPIRATION_TIME;
import static internshakti.util.Constants.SECRET;
import static internshakti.util.Constants.TOKEN_PREFIX;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class TokenService {
	private static final Logger LOGGER = LoggerFactory.getLogger(TokenService.class);

	public static String getToken(final Authentication authentication) {
		LOGGER.debug("Fetching token started");
		StringBuilder token = new StringBuilder(TOKEN_PREFIX);
		token.append(Jwts.builder().setSubject(((User) authentication.getPrincipal()).getUsername())
				.setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
				.signWith(SignatureAlgorithm.HS512, SECRET).compact());
		LOGGER.debug("Fetching token finished");
		return token.toString();
	}

	public static String validateToken(final String token) {
		LOGGER.debug("Validating token started");
		String subject = Jwts.parser().setSigningKey(SECRET).parseClaimsJws(token.replace(TOKEN_PREFIX, "")).getBody()
				.getSubject();
		LOGGER.debug("Validating token finished.");
		return subject;
	}

	public static void main(String[] args) {
		System.out.println("".equals(null));
	}
}
