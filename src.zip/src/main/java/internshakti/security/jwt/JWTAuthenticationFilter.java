package internshakti.security.jwt;

import static internshakti.util.Constants.HEADER_STRING;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.fasterxml.jackson.databind.ObjectMapper;

import internshakti.repository.mongo.dco.ApplicationUser;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

	private AuthenticationManager authenticationManager;

	private static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthenticationFilter.class);

	public JWTAuthenticationFilter(AuthenticationManager authenticationManager) {
		this.authenticationManager = authenticationManager;
	}

	@Override
	public Authentication attemptAuthentication(HttpServletRequest req, HttpServletResponse res)
			throws AuthenticationException {
		try {
			ApplicationUser creds = new ObjectMapper().readValue(req.getInputStream(), ApplicationUser.class);
			String emailOrMobile = creds.getEmail() == null ? creds.getMobile() : creds.getEmail();
			LOGGER.debug("Authentication started for: " + emailOrMobile + "/" + creds.getToken());
			if (creds.getOtp() != null && !"".equals(creds.getOtp())) {
				emailOrMobile += "```" + creds.getOtp();
			}
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(emailOrMobile, creds.getToken(), new ArrayList<>()));
			LOGGER.debug("Authentication finished.");
			return authentication;
		} catch (Exception e) {
			res.setStatus(HttpStatus.UNAUTHORIZED.value());
			LOGGER.error("Failed authentication", e);
			return null;
		}
	}

	@Override
	protected void successfulAuthentication(HttpServletRequest req, HttpServletResponse res, FilterChain chain,
			Authentication auth) throws IOException, ServletException {
		String token = TokenService.getToken(auth);
		LOGGER.debug("Setting token in header: " + token);
		res.addHeader(HEADER_STRING, token);
		res.getWriter().write(token);
		LOGGER.debug("Setting token in header finished.");

	}

}