package internshakti.endpoint;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;

import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.BaseObject;

@Controller
public class BaseEndpoint {

	@Autowired
	protected ApplicationUserRepository applicationUserRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseEndpoint.class);

	public ApplicationUser getLoggedInUser() {
		return (ApplicationUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	}

	public ApplicationUser getLoggedInUserReference() {
		return new ApplicationUser(getLoggedInUser().getId());
	}

	public boolean isOperationAllowed(BaseObject baseObject) {
		if (baseObject.getApplicationUser() != null) {
			ApplicationUser providedUser = baseObject.getApplicationUser();
			boolean isSameUser = providedUser.getId().equalsIgnoreCase(getLoggedInUserReference().getId());
			if (!isSameUser) {
				boolean isChild = applicationUserRepository.isChild(getLoggedInUserReference(), providedUser);
				if (!isChild) {
					LOGGER.debug("Operation not allowed for " + baseObject.getClass().getName()
							+ " as no relationship between:" + providedUser.getId() + ","
							+ getLoggedInUserReference().getId());
					return false;
				}
			}
		}
		return true;
	}

}
