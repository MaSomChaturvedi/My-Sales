package internshakti.endpoint;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import internshakti.repository.mongo.dao.FuturePlanRepository;
import internshakti.repository.mongo.dao.HealthInsuranceRepository;
import internshakti.repository.mongo.dao.LifeInsuranceRepository;
import internshakti.repository.mongo.dao.MotorInsuranceRepository;
import internshakti.repository.mongo.dao.OtherProductRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.FuturePlan;
import internshakti.repository.mongo.dco.HealthInsurance;
import internshakti.repository.mongo.dco.LifeInsurance;
import internshakti.repository.mongo.dco.MotorInsurance;
import internshakti.repository.mongo.dco.OtherProduct;
import internshakti.util.Utility;

@RestController
@RequestMapping("/internshakti/api/insurance")
public class InsuranceEndpoint extends BaseEndpoint {
	private static final Logger LOGGER = LoggerFactory.getLogger(InsuranceEndpoint.class);
	@Autowired
	private HealthInsuranceRepository healthInsuranceRepository;

	@Autowired
	private MotorInsuranceRepository motorInsuranceRepository;

	@Autowired
	private LifeInsuranceRepository lifeInsuranceRepository;

	@Autowired
	private OtherProductRepository otherProductRepository;

	@Autowired
	private FuturePlanRepository futurePlanRepository;

	// *******START HEALTH INSURANCE***************************************

	@RequestMapping(value = "/health", method = RequestMethod.POST)
	public ResponseEntity<String> saveHealth(@RequestBody HealthInsurance healthInsurance) {
		if (!isOperationAllowed(healthInsurance)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (healthInsurance.getApplicationUser() == null
				|| Utility.isStringEmpty(healthInsurance.getApplicationUser().getId())) {
			healthInsurance.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		healthInsurance.setId(null);
		healthInsuranceRepository.save(healthInsurance);
		healthInsurance.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/health/{id}", method = RequestMethod.GET)
	public @ResponseBody HealthInsurance getHealth(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<HealthInsurance> healthInsurance = healthInsuranceRepository.findById(id);
		if (!healthInsurance.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(healthInsurance.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		healthInsurance.get().log(LOGGER, getLoggedInUserReference(), "Fetch");
		return healthInsurance.get();
	}

	@RequestMapping(value = "/allHealth", method = RequestMethod.POST)
	public @ResponseBody List<HealthInsurance> getAllHealth(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {
		List<HealthInsurance> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = healthInsuranceRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = healthInsuranceRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed health listing for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list;
	}

	@RequestMapping(value = "/health/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteHealth(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<HealthInsurance> dbObject = healthInsuranceRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		healthInsuranceRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/health", method = RequestMethod.PUT)
	public @ResponseBody HealthInsurance updateHealth(@RequestBody HealthInsurance healthInsurance,
			HttpServletResponse response) {
		if (healthInsurance == null || Utility.isStringEmpty(healthInsurance.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<HealthInsurance> dbObject = healthInsuranceRepository.findById(healthInsurance.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		healthInsurance.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		healthInsurance.setApplicationUser(dbObject.get().getApplicationUser());
		healthInsuranceRepository.save(healthInsurance);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return healthInsurance;
	}
	// *******END HEALTH INSURANCE***************************************
	// *******START LIFE INSURANCE***************************************

	@RequestMapping(value = "/life", method = RequestMethod.POST)
	public ResponseEntity<String> saveLife(@RequestBody LifeInsurance lifeInsurance) {
		if (!isOperationAllowed(lifeInsurance)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (lifeInsurance.getApplicationUser() == null
				|| Utility.isStringEmpty(lifeInsurance.getApplicationUser().getId())) {
			lifeInsurance.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		lifeInsurance.setId(null);
		lifeInsuranceRepository.save(lifeInsurance);
		lifeInsurance.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/life/{id}", method = RequestMethod.GET)
	public @ResponseBody LifeInsurance getLife(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<LifeInsurance> lifeInsurance = lifeInsuranceRepository.findById(id);
		if (!lifeInsurance.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(lifeInsurance.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		lifeInsurance.get().log(LOGGER, getLoggedInUserReference(), "Fetch");
		return lifeInsurance.get();
	}

	@RequestMapping(value = "/allLife", method = RequestMethod.POST)
	public @ResponseBody List<LifeInsurance> getAllLife(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {
		List<LifeInsurance> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = lifeInsuranceRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = lifeInsuranceRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed life listing for reference: %s", getLoggedInUserReference().getId(),
				applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list;
	}

	@RequestMapping(value = "/life/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteLife(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<LifeInsurance> dbObject = lifeInsuranceRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		lifeInsuranceRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/life", method = RequestMethod.PUT)
	public @ResponseBody LifeInsurance updateLife(@RequestBody LifeInsurance lifeInsurance,
			HttpServletResponse response) {
		if (lifeInsurance == null || Utility.isStringEmpty(lifeInsurance.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<LifeInsurance> dbObject = lifeInsuranceRepository.findById(lifeInsurance.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		lifeInsurance.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		lifeInsurance.setApplicationUser(dbObject.get().getApplicationUser());
		lifeInsuranceRepository.save(lifeInsurance);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return lifeInsurance;
	}

	// *******END LIFE INSURANCE***************************************
	// *******START MOTOR INSURANCE***************************************

	@RequestMapping(value = "/motor", method = RequestMethod.POST)
	public ResponseEntity<String> saveMotor(@RequestBody MotorInsurance motorInsurance) {
		if (!isOperationAllowed(motorInsurance)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (motorInsurance.getApplicationUser() == null
				|| Utility.isStringEmpty(motorInsurance.getApplicationUser().getId())) {
			motorInsurance.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		motorInsurance.setId(null);
		motorInsuranceRepository.save(motorInsurance);
		motorInsurance.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/motor/{id}", method = RequestMethod.GET)
	public @ResponseBody MotorInsurance getMotor(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<MotorInsurance> motorInsurance = motorInsuranceRepository.findById(id);
		if (!motorInsurance.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(motorInsurance.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		motorInsurance.get().log(LOGGER, getLoggedInUserReference(), "Fetch");
		return motorInsurance.get();
	}

	@RequestMapping(value = "/allMotor", method = RequestMethod.POST)
	public @ResponseBody List<MotorInsurance> getAllMotor(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {

		List<MotorInsurance> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = motorInsuranceRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = motorInsuranceRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed health listing for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list;
	}

	@RequestMapping(value = "/motor/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteMotor(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<MotorInsurance> dbObject = motorInsuranceRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		motorInsuranceRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/motor", method = RequestMethod.PUT)
	public @ResponseBody MotorInsurance updateMotor(@RequestBody MotorInsurance motorInsurance,
			HttpServletResponse response) {
		if (motorInsurance == null || Utility.isStringEmpty(motorInsurance.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<MotorInsurance> dbObject = motorInsuranceRepository.findById(motorInsurance.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		motorInsurance.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		motorInsurance.setApplicationUser(dbObject.get().getApplicationUser());
		motorInsuranceRepository.save(motorInsurance);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return motorInsurance;
	}
	// *******END MOTOR INSURANCE***************************************

	// *******START OTHER PRODUCT***************************************

	@RequestMapping(value = "/other", method = RequestMethod.POST)
	public ResponseEntity<String> saveOtherProduct(@RequestBody OtherProduct otherProduct) {
		if (!isOperationAllowed(otherProduct)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (otherProduct.getApplicationUser() == null
				|| Utility.isStringEmpty(otherProduct.getApplicationUser().getId())) {
			otherProduct.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		otherProduct.setId(null);
		otherProductRepository.save(otherProduct);
		otherProduct.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/other/{id}", method = RequestMethod.GET)
	public @ResponseBody OtherProduct getOtherProduct(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<OtherProduct> otherProduct = otherProductRepository.findById(id);
		if (!otherProduct.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(otherProduct.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		otherProduct.get().log(LOGGER, getLoggedInUserReference(), "Fetch");
		return otherProduct.get();
	}

	@RequestMapping(value = "/allOther", method = RequestMethod.POST)
	public @ResponseBody List<OtherProduct> getAllOtherProduct(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {

		List<OtherProduct> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = otherProductRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = otherProductRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed health listing for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list;
	}

	@RequestMapping(value = "/other/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteOtherProduct(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<OtherProduct> dbObject = otherProductRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		otherProductRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/other", method = RequestMethod.PUT)
	public @ResponseBody OtherProduct updateOtherProduct(@RequestBody OtherProduct otherProduct,
			HttpServletResponse response) {
		if (otherProduct == null || Utility.isStringEmpty(otherProduct.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<OtherProduct> dbObject = otherProductRepository.findById(otherProduct.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		otherProduct.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		otherProduct.setApplicationUser(dbObject.get().getApplicationUser());
		otherProductRepository.save(otherProduct);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return otherProduct;
	}
	// *******END OTHER PRODUCT***************************************
	// *******START FUTURE PLAN***************************************

	@RequestMapping(value = "/future", method = RequestMethod.POST)
	public ResponseEntity<String> saveFuturePlan(@RequestBody FuturePlan futurePlan) {
		if (!isOperationAllowed(futurePlan)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (futurePlan.getApplicationUser() == null || Utility.isStringEmpty(futurePlan.getApplicationUser().getId())) {
			futurePlan.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		futurePlan.setId(null);
		futurePlanRepository.save(futurePlan);
		futurePlan.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/future/{id}", method = RequestMethod.GET)
	public @ResponseBody FuturePlan getFuturePlan(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<FuturePlan> futurePlan = futurePlanRepository.findById(id);
		if (!futurePlan.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(futurePlan.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		futurePlan.get().log(LOGGER, getLoggedInUserReference(), "Fetch");
		return futurePlan.get();
	}

	@RequestMapping(value = "/allFuture", method = RequestMethod.POST)
	public @ResponseBody List<FuturePlan> getAllFuturePlan(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {

		List<FuturePlan> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = futurePlanRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = futurePlanRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed health listing for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list;
	}

	@RequestMapping(value = "/future/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteFuturePlan(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<FuturePlan> dbObject = futurePlanRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		futurePlanRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/future", method = RequestMethod.PUT)
	public @ResponseBody FuturePlan updateFuturePlan(@RequestBody FuturePlan futurePlan, HttpServletResponse response) {
		if (futurePlan == null || Utility.isStringEmpty(futurePlan.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<FuturePlan> dbObject = futurePlanRepository.findById(futurePlan.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		futurePlan.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		futurePlan.setApplicationUser(dbObject.get().getApplicationUser());
		futurePlanRepository.save(futurePlan);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return futurePlan;
	}
	// *******END FUTURE PLAN***************************************
}
