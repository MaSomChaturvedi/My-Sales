package internshakti.endpoint;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import internshakti.exception.InvalidEmployeeId;
import internshakti.exception.InvalidOTPException;
import internshakti.exception.UserExistException;
import internshakti.repository.mongo.dao.ApplicationUserRepository;
import internshakti.repository.mongo.dao.ApplicationVisitorRepository;
import internshakti.repository.mongo.dao.EmployeeDetailRepository;
import internshakti.repository.mongo.dao.LeadGenerationRepository;
import internshakti.repository.mongo.dao.MasterDataRepository;
import internshakti.repository.mongo.dao.UserDetailRepository;
import internshakti.repository.mongo.dao.UserProfileRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.ApplicationUser.Role;
import internshakti.repository.mongo.dco.ApplicationVisitor;
import internshakti.repository.mongo.dco.EmployeeDetail;
import internshakti.repository.mongo.dco.LeadGeneration;
import internshakti.repository.mongo.dco.MasterData;
import internshakti.repository.mongo.dco.UserDetail;
import internshakti.repository.mongo.dco.UserProfile;
import internshakti.service.UserService;
import internshakti.service.mail.GmailMailSender;
import internshakti.util.RandomGenerator;
import internshakti.util.Utility;

@RestController
@RequestMapping("/internshakti/api")
public class UserEndpoint extends BaseEndpoint {
	private static final Logger LOGGER = LoggerFactory.getLogger(UserEndpoint.class);
	@Autowired
	private ApplicationUserRepository userRepository;
	@Autowired
	private ApplicationVisitorRepository visitorRepository;
	@Autowired
	private MasterDataRepository masterDataRepository;
	@Autowired
	private EmployeeDetailRepository employeeDetailRepository;
	@Autowired
	private UserDetailRepository userDetailRepository;
	@Autowired
	private UserProfileRepository userProfileRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private UserService userService;
	@Autowired
	private GmailMailSender mailSender;
	@Autowired
	private LeadGenerationRepository leadGenerationRepository;

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ResponseEntity<String> register(@RequestBody ApplicationUser user) {
		LOGGER.debug("Saving User Started.");
		try {
			if (user == null || Utility.isStringEmpty(user.getEmail()) || Utility.isStringEmpty(user.getMobile())
					|| Utility.isStringEmpty(user.getToken()) || Utility.isStringEmpty(user.getOtp())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			}
			userService.checkUserAlreadyExist(user);
			userService.validateUserOTP(user);
		} catch (UserExistException e) {
			LOGGER.error("User already exist", e);
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		} catch (InvalidOTPException e) {
			LOGGER.error("User OTP not valid", e);
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		user.setToken(bCryptPasswordEncoder.encode(user.getToken()));
		try {
			userService.saveUser(user);
		} catch (InvalidEmployeeId e) {
			LOGGER.error("Invalid Employee ID", e);
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		LOGGER.debug("Saving User Finished.");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/registerWeb", method = RequestMethod.POST)
	public ResponseEntity<String> registerFromWeb(@RequestBody ApplicationUser user) {
		LOGGER.debug("Saving User Started.");
		try {
			if (user == null || Utility.isStringEmpty(user.getEmail()) || Utility.isStringEmpty(user.getMobile())
					|| Utility.isStringEmpty(user.getToken()) || Utility.isStringEmpty(user.getOtp())) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
			}

			userService.validateUserOTP(user);
		} catch (InvalidOTPException e) {
			LOGGER.error("User OTP not valid", e);
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		user.setToken(bCryptPasswordEncoder.encode(user.getToken()));
		try {
			userService.saveUser(user);
		} catch (InvalidEmployeeId e) {
			LOGGER.error("Invalid Employee ID", e);
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		LOGGER.debug("Saving User Finished.");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/registerDetails", method = RequestMethod.POST)
	public ResponseEntity<String> registerDetails(String userEmail,
			@RequestParam("agentPhoto") MultipartFile agentPhoto,
			@RequestParam("agentPanCard") MultipartFile agentPanCard,
			@RequestParam("agentAddressProf1") MultipartFile agentAddressProf1,
			@RequestParam("agentAddressProf2") MultipartFile agentAddressProf2,
			@RequestParam("agencyPhoto") MultipartFile agencyPhoto,
			@RequestParam("agencyPanCard") MultipartFile agencyPanCard,
			@RequestParam("agencyAddressProf1") MultipartFile agencyAddressProf1,
			@RequestParam("agencyAddressProf2") MultipartFile agencyAddressProf2,
			@RequestParam("companyGst") MultipartFile companyGst,
			@RequestParam("companyCoi") MultipartFile companyCoi) {
		LOGGER.debug("Start fetching user");
		ApplicationUser user = userRepository.findByEmail(getLoggedInUser().getEmail());
		try {
			if (agentPhoto != null) {
				user.setAgentPhoto(new Binary(BsonBinarySubType.BINARY, agentPhoto.getBytes()));
			}
			if (agentPanCard != null) {
				user.setAgentPanCard(new Binary(BsonBinarySubType.BINARY, agentPanCard.getBytes()));
			}
			if (agentAddressProf1 != null) {
				user.setAgentAddressProf1(new Binary(BsonBinarySubType.BINARY, agentAddressProf1.getBytes()));
			}
			if (agentAddressProf2 != null) {
				user.setAgentAddressProf2(new Binary(BsonBinarySubType.BINARY, agentAddressProf2.getBytes()));
			}
			if (agencyPhoto != null) {
				user.setAgencyPhoto(new Binary(BsonBinarySubType.BINARY, agencyPhoto.getBytes()));
			}
			if (agencyPanCard != null) {
				user.setAgencyPanCard(new Binary(BsonBinarySubType.BINARY, agencyPanCard.getBytes()));
			}
			if (agencyAddressProf1 != null) {
				user.setAgencyAddressProf1(new Binary(BsonBinarySubType.BINARY, agencyAddressProf1.getBytes()));
			}
			if (agencyAddressProf2 != null) {
				user.setAgencyAddressProf2(new Binary(BsonBinarySubType.BINARY, agencyAddressProf2.getBytes()));
			}
			if (companyGst != null) {
				user.setCompanyGst(new Binary(BsonBinarySubType.BINARY, companyGst.getBytes()));
			}
			if (companyCoi != null) {
				user.setCompanyCoi(new Binary(BsonBinarySubType.BINARY, companyCoi.getBytes()));
			}

		} catch (IOException e) {
			LOGGER.error("FileNot Found", e);
		}
		try {
			userService.saveUser(user);
		} catch (InvalidEmployeeId e) {
			LOGGER.error("Invalid Employee ID", e);
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		LOGGER.debug("Saving User Finished.");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/changetoken", method = RequestMethod.PUT)
	public ResponseEntity<String> changeToken(@RequestBody ApplicationUser user) {
		LOGGER.debug("Changing token Started.");
		if (user == null || Utility.isStringEmpty(user.getToken())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		final String token = user.getToken();
		user = userRepository.findByEmail(getLoggedInUser().getEmail());
		if (user == null) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
		}
		user.setToken(bCryptPasswordEncoder.encode(token));
		userRepository.save(user);
		LOGGER.debug("Changing token Finished.");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public @ResponseBody ApplicationUser getUser() {
		LOGGER.debug("Start fetching user");
		ApplicationUser user = userRepository.findByEmail(getLoggedInUser().getEmail());
		cleanApplicationUser(user);
		LOGGER.debug("End fetching user");
		return user;
	}

	@RequestMapping(value = "/masterdata", method = RequestMethod.GET)
	public @ResponseBody MasterData getMasterData() {
		LOGGER.debug("Start fetching masterData");
		MasterData masterData = masterDataRepository.findAll().get(0);
		LOGGER.debug("End fetching masterData");
		return masterData;
	}

	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public ResponseEntity<String> creatEmployee(@RequestBody EmployeeDetail employeeDetail) {
		LOGGER.debug("Saving Employee Started.");
		if (employeeDetail == null || Utility.isStringEmpty(employeeDetail.getEmpId())
				|| employeeDetail.getRole() == null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		EmployeeDetail existEmployee = employeeDetailRepository.findByEmpId(employeeDetail.getEmpId());
		if (existEmployee != null) {
			LOGGER.debug("Employee ID already exist: ", employeeDetail.getId());
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		employeeDetail.setOwner(getLoggedInUserReference());
		employeeDetailRepository.save(employeeDetail);
		LOGGER.debug("Saving Employee Finished.");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/employee", method = RequestMethod.GET)
	public @ResponseBody List<EmployeeDetail> getEmployeeDetails() {
		LOGGER.debug("Start fetching employee");
		List<EmployeeDetail> employees = employeeDetailRepository.findByOwner(getLoggedInUserReference());
		LOGGER.debug("End fetching employee");
		return employees;
	}

	@RequestMapping(value = "/getlotp", method = RequestMethod.POST)
	public ResponseEntity<String> loginOTP(@RequestBody ApplicationUser applicationUser) {
		LOGGER.debug("Sending OTP Started.");
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getEmail())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		ApplicationUser dbUser = userRepository.findByEmail(applicationUser.getEmail());
		if (dbUser == null || !Role.ROLE_ADMIN.equals(dbUser.getRole())) {
			LOGGER.debug("User is not admin or not exist in db: ", applicationUser.getEmail());
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (!dbUser.shouldAgainSendOTP()) {
			LOGGER.debug("Already sent otp for: ", applicationUser.getEmail());
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		String otp = RandomGenerator.getRandomOTP();
		dbUser.setOtp(otp);
		dbUser.setOtpGeneratedTime(new Date());
		mailSender.sendOTP(dbUser);
		userRepository.save(dbUser);
		LOGGER.debug("Sending OTP Finished.");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/getfotp", method = RequestMethod.POST)
	public ResponseEntity<String> forgetPasswordOTP(@RequestBody ApplicationUser applicationUser) {
		LOGGER.debug("Sending Forget OTP Started.");
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getEmail())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		ApplicationUser dbUser = userRepository.findByEmail(applicationUser.getEmail());
		if (dbUser == null) {
			LOGGER.debug("User not exist in db: ", applicationUser.getEmail());
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (!dbUser.shouldAgainSendOTP()) {
			LOGGER.debug("Already sent otp for: ", applicationUser.getEmail());
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		String otp = RandomGenerator.getRandomOTP();
		dbUser.setOtp(otp);
		dbUser.setOtpGeneratedTime(new Date());
		mailSender.sendOTP(dbUser);
		userRepository.save(dbUser);
		LOGGER.debug("Sending Forget OTP Finished.");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/getrotp", method = RequestMethod.POST)
	public ResponseEntity<String> forgetPasswordOTP(@RequestBody ApplicationVisitor applicationVisitor) {
		LOGGER.debug("Sending Register OTP Started.");
		if (applicationVisitor == null || Utility.isStringEmpty(applicationVisitor.getEmail())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		ApplicationVisitor dbUser = visitorRepository.findByEmail(applicationVisitor.getEmail());

		if (dbUser != null && !dbUser.shouldAgainSendOTP()) {
			LOGGER.debug("Already sent otp for: ", dbUser.getEmail());
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		if (dbUser != null) {
			mailSender.sendOTP(dbUser);
			LOGGER.debug("Sending Register OTP Finished.");
			return ResponseEntity.status(HttpStatus.OK).build();
		} else {
			String otp = RandomGenerator.getRandomOTP();
			applicationVisitor.setOtp(otp);
			applicationVisitor.setOtpGeneratedTime(new Date());
			mailSender.sendOTP(applicationVisitor);
			visitorRepository.save(applicationVisitor);
			LOGGER.debug("Sending Register OTP Finished.");
			return ResponseEntity.status(HttpStatus.OK).build();
		}
	}

	@RequestMapping(value = "/resettoken", method = RequestMethod.PUT)
	public ResponseEntity<String> resetToken(@RequestBody ApplicationUser user) {
		LOGGER.debug("Changing token Started.");
		if (user == null || Utility.isStringEmpty(user.getToken()) || Utility.isStringEmpty(user.getEmail())
				|| Utility.isStringEmpty(user.getOtp())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
		}
		String token = user.getToken();
		String otp = user.getOtp();
		user = userRepository.findByEmail(user.getEmail());
		if (user == null || !user.validOTP() || !user.getOtp().trim().equals(otp.trim())) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		user.setToken(bCryptPasswordEncoder.encode(token));
		userRepository.save(user);
		LOGGER.debug("Changing token Finished.");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/getchild", method = RequestMethod.GET)
	public @ResponseBody List<ApplicationUser> getChildUsers() {
		LOGGER.debug("Start fetching child users");
		List<ApplicationUser> users = userRepository.getAllChild(getLoggedInUserReference());
		for (ApplicationUser user : users) {
			cleanApplicationUser(user);
		}
		LOGGER.debug("End fetching child users.");
		return users;
	}

	// *******START User Details***************************************

	@RequestMapping(value = "/userdetail", method = RequestMethod.POST)
	public ResponseEntity<String> saveUserDetail(@RequestBody UserDetail userDetail) {
		if (!isOperationAllowed(userDetail)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (userDetail.getApplicationUser() == null || Utility.isStringEmpty(userDetail.getApplicationUser().getId())) {
			userDetail.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		userDetail.setId(null);
		userDetailRepository.save(userDetail);
		userDetail.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/getuserdetail", method = RequestMethod.POST)
	public @ResponseBody UserDetail getUserDetail(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {

		List<UserDetail> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = userDetailRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = userDetailRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed user detail fetching for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list != null && list.size() > 0 ? list.get(0) : null;
	}

	@RequestMapping(value = "/userdetail/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteUserDetail(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<UserDetail> dbObject = userDetailRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		userDetailRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/userdetail", method = RequestMethod.PUT)
	public @ResponseBody UserDetail updateUserDetail(@RequestBody UserDetail userDetail, HttpServletResponse response) {
		if (userDetail == null || Utility.isStringEmpty(userDetail.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<UserDetail> dbObject = userDetailRepository.findById(userDetail.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		userDetail.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		userDetail.setApplicationUser(dbObject.get().getApplicationUser());
		userDetailRepository.save(userDetail);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return userDetail;
	}
	// *******END User Details***************************************
	// *******START User Profile***************************************

	@RequestMapping(value = "/profile", method = RequestMethod.POST)
	public ResponseEntity<String> saveUserProfile(@RequestBody UserProfile userProfile) {
		if (!isOperationAllowed(userProfile)) {
			return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).build();
		}
		if (userProfile.getApplicationUser() == null
				|| Utility.isStringEmpty(userProfile.getApplicationUser().getId())) {
			userProfile.setApplicationUser(getLoggedInUserReference());
		}
		// doesn't matter whatever end user set it.
		userProfile.setId(null);
		userProfileRepository.save(userProfile);
		userProfile.log(LOGGER, getLoggedInUserReference(), "Persist");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	@RequestMapping(value = "/getprofile", method = RequestMethod.POST)
	public @ResponseBody UserProfile getUserProfile(@RequestBody ApplicationUser applicationUser,
			HttpServletResponse response) {

		List<UserProfile> list = null;
		if (applicationUser == null || Utility.isStringEmpty(applicationUser.getId())) {
			list = userProfileRepository.findByApplicationUser(getLoggedInUserReference());
		} else if (applicationUserRepository.isChild(getLoggedInUserReference(), applicationUser)) {
			list = userProfileRepository.findByApplicationUser(applicationUser);
		} else {
			LOGGER.debug("Operation not allowed as no relationship between:" + applicationUser.getId() + ","
					+ getLoggedInUserReference().getId());
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		LOGGER.debug("Logged-In User: %s, performed user profile fetching for reference: %s",
				getLoggedInUserReference().getId(), applicationUser.getId() != null ? applicationUser.getId() : "self");
		return list != null && list.size() > 0 ? list.get(0) : null;
	}

	@RequestMapping(value = "/profile/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteUserProfile(@PathVariable String id, HttpServletResponse response) {
		if (Utility.isStringEmpty(id)) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<UserProfile> dbObject = userProfileRepository.findById(id);
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		userProfileRepository.deleteById(id);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Delete");
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/profile", method = RequestMethod.PUT)
	public @ResponseBody UserProfile updateUserDetail(@RequestBody UserProfile userProfile,
			HttpServletResponse response) {
		if (userProfile == null || Utility.isStringEmpty(userProfile.getId())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		Optional<UserProfile> dbObject = userProfileRepository.findById(userProfile.getId());
		if (!dbObject.isPresent()) {
			response.setStatus(HttpStatus.NOT_FOUND.value());
			return null;
		}
		userProfile.setApplicationUser(null);
		if (!isOperationAllowed(dbObject.get())) {
			response.setStatus(HttpStatus.NOT_ACCEPTABLE.value());
			return null;
		}
		userProfile.setApplicationUser(dbObject.get().getApplicationUser());
		userProfileRepository.save(userProfile);
		dbObject.get().log(LOGGER, getLoggedInUserReference(), "Update");
		return userProfile;
	}

	@RequestMapping(value = "/saveLeadGenertion", method = RequestMethod.POST)
	public ResponseEntity<String> saveLeadGeneration(@RequestBody LeadGeneration leadGeneration) {
		LOGGER.debug("Saving LeadGeneration Started.");

		try {
			leadGeneration.setLeadGenerator(getLoggedInUserReference());
			leadGenerationRepository.save(leadGeneration);
		} catch (Exception e) {
			LOGGER.error("Invalid LeadD", e);
			return ResponseEntity.status(HttpStatus.ALREADY_REPORTED).build();
		}
		LOGGER.debug("Saving LeadGeneration Finished.");
		return ResponseEntity.status(HttpStatus.CREATED).build();
	}

	// *******END User Profile***************************************

	private void cleanApplicationUser(ApplicationUser user) {
		user.setToken(null);
		user.setOtp(null);
		user.setOtpGeneratedTime(null);
		user.setParentUser(null);
	}

}
