package internshakti.repository.mongo.util;

import org.bson.Document;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperationContext;

import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class MongoUtil {

	/**
	 * We can use GraphLookupQueryBuilder but there was some error with this API as failed to use nested id
	 * So introduced below method
	 */
	public static AggregationOperation getGraphLookupOperation(String from, String startWith, String connectFrom,
			String connectTo, String asOutput) {
		AggregationOperation aggregationOperation = new AggregationOperation() {
			@Override
			public Document toDocument(AggregationOperationContext context) {
				DBObject graphLookup = new BasicDBObject("from", from).append("startWith", startWith)
						.append("connectFromField", connectFrom).append("connectToField", connectTo)
						.append("as", asOutput);
				return new Document("$graphLookup", graphLookup);
			}
		};
		return aggregationOperation;
	}

}
