package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.LeadGeneration;

public interface LeadGenerationRepository extends MongoRepository<LeadGeneration, String> {
	//public List<LeadGeneration> findByLeadGeneration(LeadGeneration leadGeneration);
}
