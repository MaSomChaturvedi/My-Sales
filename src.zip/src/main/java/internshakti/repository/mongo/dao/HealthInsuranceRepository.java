package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.HealthInsurance;

public interface HealthInsuranceRepository extends MongoRepository<HealthInsurance, String> {
	public List<HealthInsurance> findByApplicationUser(ApplicationUser applicationUser);
}
