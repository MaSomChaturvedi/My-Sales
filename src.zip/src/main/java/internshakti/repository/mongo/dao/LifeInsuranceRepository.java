package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.LifeInsurance;

public interface LifeInsuranceRepository extends MongoRepository<LifeInsurance, String> {
	public List<LifeInsurance> findByApplicationUser(ApplicationUser applicationUser);
}
