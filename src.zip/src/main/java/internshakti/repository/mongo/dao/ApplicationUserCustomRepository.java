package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import internshakti.repository.mongo.dco.ApplicationUser;

@Repository
public interface ApplicationUserCustomRepository {
	List<ApplicationUser> getAllChild(ApplicationUser applicationUser);

	boolean isChild(ApplicationUser parent, ApplicationUser child);
}
