package internshakti.repository.mongo.dao;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.MasterData;

public interface MasterDataRepository extends MongoRepository<MasterData, String> {
}
