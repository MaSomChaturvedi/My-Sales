package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.FuturePlan;

public interface FuturePlanRepository extends MongoRepository<FuturePlan, String> {
	public List<FuturePlan> findByApplicationUser(ApplicationUser applicationUser);
}
