package internshakti.repository.mongo.dao.impl;

import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.query.Criteria;

import internshakti.repository.mongo.dao.ApplicationUserCustomRepository;
import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.util.MongoUtil;

public class ApplicationUserCustomRepositoryImpl implements ApplicationUserCustomRepository {

	@Autowired
	private MongoTemplate mongoTemplate;

	@Override
	public List<ApplicationUser> getAllChild(ApplicationUser applicationUser) {
		ObjectId userId = new ObjectId(applicationUser.getId());
		Criteria criteria = Criteria.where("_id").is(userId);
		MatchOperation matchOperation = Aggregation.match(criteria);
		AggregationOperation aggregationOperation = MongoUtil.getGraphLookupOperation("applicationUser", "$_id", "_id",
				"parentUser._id", "childs");
		Aggregation aggregation = Aggregation.newAggregation(aggregationOperation, matchOperation);
		List<ApplicationUser> users = mongoTemplate.aggregate(aggregation, "applicationUser", ApplicationUser.class)
				.getMappedResults();
		List<ApplicationUser> childs = users != null ? users.get(0).getChilds() : null;
		return childs;
	}

	@Override
	public boolean isChild(ApplicationUser parent, ApplicationUser child) {
		List<ApplicationUser> childs = getAllChild(parent);
		for (ApplicationUser childObject : childs) {
			if (child.getId().equals(childObject.getId())) {
				return true;
			}
		}
		return false;
	}

}
