package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.UserProfile;

public interface UserProfileRepository extends MongoRepository<UserProfile, String> {
	public List<UserProfile> findByApplicationUser(ApplicationUser applicationUser);
}
