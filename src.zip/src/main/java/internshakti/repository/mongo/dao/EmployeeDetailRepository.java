package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.EmployeeDetail;

@Repository
public interface EmployeeDetailRepository extends MongoRepository<EmployeeDetail, String> {
	public EmployeeDetail findByEmpId(String empId);
	public EmployeeDetail findByEmpIdAndAssigned(String empId, boolean assigned);
	public List<EmployeeDetail> findByOwner(ApplicationUser owner);
}
