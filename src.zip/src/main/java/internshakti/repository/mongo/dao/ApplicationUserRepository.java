package internshakti.repository.mongo.dao;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import internshakti.repository.mongo.dco.ApplicationUser;

@Repository
public interface ApplicationUserRepository
		extends MongoRepository<ApplicationUser, String>, ApplicationUserCustomRepository {
	ApplicationUser findByEmail(String email);

	ApplicationUser findByMobile(String mobile);
}
