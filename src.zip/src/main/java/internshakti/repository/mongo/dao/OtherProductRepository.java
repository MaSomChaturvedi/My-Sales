package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.OtherProduct;

public interface OtherProductRepository extends MongoRepository<OtherProduct, String> {
	public List<OtherProduct> findByApplicationUser(ApplicationUser applicationUser);
}
