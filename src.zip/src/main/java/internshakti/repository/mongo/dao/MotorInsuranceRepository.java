package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.MotorInsurance;

public interface MotorInsuranceRepository extends MongoRepository<MotorInsurance, String> {
	public List<MotorInsurance> findByApplicationUser(ApplicationUser applicationUser);
}
