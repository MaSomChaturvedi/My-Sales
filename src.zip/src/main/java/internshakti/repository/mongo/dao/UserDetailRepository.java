package internshakti.repository.mongo.dao;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import internshakti.repository.mongo.dco.ApplicationUser;
import internshakti.repository.mongo.dco.UserDetail;

public interface UserDetailRepository extends MongoRepository<UserDetail, String> {
	public List<UserDetail> findByApplicationUser(ApplicationUser applicationUser);
}
