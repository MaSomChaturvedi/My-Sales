package internshakti.repository.mongo.dco;

import java.util.Date;

public class LifeInsurance extends InsuranceBase {
	private String planName;
	private Double sumAssured;
	private Byte policyTerm;
	private Byte premiumPaymentTerm;
	private String nomineeName;
	private String productType;
	private Date lastPaidDate;
	private Double maturityAmount;

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Double getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}

	public Byte getPolicyTerm() {
		return policyTerm;
	}

	public void setPolicyTerm(Byte policyTerm) {
		this.policyTerm = policyTerm;
	}

	public Byte getPremiumPaymentTerm() {
		return premiumPaymentTerm;
	}

	public void setPremiumPaymentTerm(Byte premiumPaymentTerm) {
		this.premiumPaymentTerm = premiumPaymentTerm;
	}

	public String getNomineeName() {
		return nomineeName;
	}

	public void setNomineeName(String nomineeName) {
		this.nomineeName = nomineeName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public Date getLastPaidDate() {
		return lastPaidDate;
	}

	public void setLastPaidDate(Date lastPaidDate) {
		this.lastPaidDate = lastPaidDate;
	}

	public Double getMaturityAmount() {
		return maturityAmount;
	}

	public void setMaturityAmount(Double maturityAmount) {
		this.maturityAmount = maturityAmount;
	}
}
