package internshakti.repository.mongo.dco;

import java.util.List;

public class UserDetail extends BaseObject {

	private List<FamilyDetail> familyDetails;

	private List<QuickReference> quickReferences;

	public List<FamilyDetail> getFamilyDetails() {
		return familyDetails;
	}

	public void setFamilyDetails(List<FamilyDetail> familyDetails) {
		this.familyDetails = familyDetails;
	}

	public List<QuickReference> getQuickReferences() {
		return quickReferences;
	}

	public void setQuickReferences(List<QuickReference> quickReferences) {
		this.quickReferences = quickReferences;
	}
}
