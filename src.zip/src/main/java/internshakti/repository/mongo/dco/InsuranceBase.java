package internshakti.repository.mongo.dco;

import java.util.Date;

public class InsuranceBase extends BaseObject {

	private String companyName;
	private String policyNumber;
	private String policyHolderName;
	private Date policyStartDate;
	private Date policyEndDate;
	private Date renewDate;
	private Double premiumAmount;
	private Byte premiumPaymentFrequency;
	private String advisorContactDetail;
	private String otherDetail;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public Date getPolicyStartDate() {
		return policyStartDate;
	}

	public void setPolicyStartDate(Date policyStartDate) {
		this.policyStartDate = policyStartDate;
	}

	public Date getPolicyEndDate() {
		return policyEndDate;
	}

	public void setPolicyEndDate(Date policyEndDate) {
		this.policyEndDate = policyEndDate;
	}

	public Date getRenewDate() {
		return renewDate;
	}

	public void setRenewDate(Date renewDate) {
		this.renewDate = renewDate;
	}

	public Double getPremiumAmount() {
		return premiumAmount;
	}

	public void setPremiumAmount(Double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}

	public Byte getPremiumPaymentFrequency() {
		return premiumPaymentFrequency;
	}

	public void setPremiumPaymentFrequency(Byte premiumPaymentFrequency) {
		this.premiumPaymentFrequency = premiumPaymentFrequency;
	}

	public String getAdvisorContactDetail() {
		return advisorContactDetail;
	}

	public void setAdvisorContactDetail(String advisorContactDetail) {
		this.advisorContactDetail = advisorContactDetail;
	}

	public String getOtherDetail() {
		return otherDetail;
	}

	public void setOtherDetail(String otherDetail) {
		this.otherDetail = otherDetail;
	}

}
