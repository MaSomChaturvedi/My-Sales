package internshakti.repository.mongo.dco;

import java.util.Date;

import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.springframework.data.annotation.Id;

public class BaseObject {
	@Id
	public String id;
	private ApplicationUser applicationUser;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public ApplicationUser getApplicationUser() {
		return applicationUser;
	}

	public void setApplicationUser(ApplicationUser applicationUser) {
		this.applicationUser = applicationUser;
	}

	public void log(Logger logger, ApplicationUser loggedinUser, String operation) {
		logger.debug("Logged-In User: %s, performed operation: %s on object: %s, with reference: %s for type: %s",
				loggedinUser.getId(), operation, getId(), applicationUser.getId(), this.getClass().getName());
	}
	public Date createdTime() {
		return new ObjectId(id).getDate();
	}
}
