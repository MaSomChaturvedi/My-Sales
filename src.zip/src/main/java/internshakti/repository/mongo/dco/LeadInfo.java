package internshakti.repository.mongo.dco;

public class LeadInfo extends BaseObject {
	private String mobile;
	private String email;
	private String name;
	private Long lattitude;
	private Long longitude;
	private String address;
	private String description;

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getLattitude() {
		return lattitude;
	}

	public void setLattitude(Long lattitude) {
		this.lattitude = lattitude;
	}

	public Long getLongitude() {
		return longitude;
	}

	public void setLongitude(Long longitude) {
		this.longitude = longitude;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
