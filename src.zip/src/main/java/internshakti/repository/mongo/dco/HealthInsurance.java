package internshakti.repository.mongo.dco;

public class HealthInsurance extends InsuranceBase {
	private String planName;
	private Byte numberOfFamilyMember;
	private Double sumAssured;
	private String tpaContactNumber;
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Byte getNumberOfFamilyMember() {
		return numberOfFamilyMember;
	}
	public void setNumberOfFamilyMember(Byte numberOfFamilyMember) {
		this.numberOfFamilyMember = numberOfFamilyMember;
	}
	public Double getSumAssured() {
		return sumAssured;
	}
	public void setSumAssured(Double sumAssured) {
		this.sumAssured = sumAssured;
	}
	public String getTpaContactNumber() {
		return tpaContactNumber;
	}
	public void setTpaContactNumber(String tpaContactNumber) {
		this.tpaContactNumber = tpaContactNumber;
	}
}
