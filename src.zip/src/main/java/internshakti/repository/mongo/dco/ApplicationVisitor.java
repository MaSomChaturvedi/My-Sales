package internshakti.repository.mongo.dco;

import java.util.Calendar;
import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

public class ApplicationVisitor {
	@Id
	private String id;
	private String email;
	private String otp;
	private Date otpGeneratedTime;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Date getOtpGeneratedTime() {
		return otpGeneratedTime;
	}

	public void setOtpGeneratedTime(Date otpGeneratedTime) {
		this.otpGeneratedTime = otpGeneratedTime;
	}
	public boolean shouldAgainSendOTP() {
		if (otpGeneratedTime == null) {
			return true;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(otpGeneratedTime);
		calendar.add(Calendar.MINUTE, 5);
		return calendar.getTime().before(new Date());
	}
	

	public Date createdTime() {
		return new ObjectId(id).getDate();
	}
}
