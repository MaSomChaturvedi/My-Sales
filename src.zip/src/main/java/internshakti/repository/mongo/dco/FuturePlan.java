package internshakti.repository.mongo.dco;

import java.util.Date;

public class FuturePlan extends BaseObject {

	private String productName;
	private String description;
	private Date planDate;

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getPlanDate() {
		return planDate;
	}

	public void setPlanDate(Date planDate) {
		this.planDate = planDate;
	}

}
