package internshakti.repository.mongo.dco;

import internshakti.repository.mongo.dco.ApplicationUser.Role;

public class MasterData {
	public String[] productType = new String[] { "Endowment", "ULIP", "MoneyBack", "Term", "WholeLife" };
	public String[] relatioship = new String[] { "Father", "Monther", "Brother", "Sister", "Spouse", "Children" };
	public String[] futurePlans = new String[] { "Life Insurance", "Health Insurance", "Personal Loan", "Auto Loan",
			"Business Loan", "Home Loan", "Other" };
	public String[] quickReferences = new String[] { "Chartered Accountant", "Doctor", "City Cable", "Maid", "Plumber",
			"Laundry", "Carpaenter", "Electrician", "School", "Driver", "Office", "Grocery", "Parlour", "Other" };
	public String[] roles = Role.getRoles();

}
