package internshakti.repository.mongo.dco;

import org.springframework.data.annotation.Id;

import internshakti.repository.mongo.dco.ApplicationUser.Role;

public class EmployeeDetail {
	@Id
	private String id;
	private String empId;
	private ApplicationUser owner;
	private Role role;
	private boolean assigned;
	private String assignTo;
	
	public String getAssignTo() {
		return assignTo;
	}
	public void setAssignTo(String assignTo) {
		this.assignTo = assignTo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public ApplicationUser getOwner() {
		return owner;
	}
	public void setOwner(ApplicationUser owner) {
		this.owner = owner;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public boolean isAssigned() {
		return assigned;
	}
	public void setAssigned(boolean assigned) {
		this.assigned = assigned;
	}
	
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
}
