package internshakti.repository.mongo.dco;

public class MotorInsurance extends InsuranceBase {

	private String vehicleRegNumber;
	private String carCompany;
	private String carModel;
	private Double insuredDeclaredValue;
	private String typeOfCover;
	private Boolean noClaimBonusEligble;
	public String getVehicleRegNumber() {
		return vehicleRegNumber;
	}
	public void setVehicleRegNumber(String vehicleRegNumber) {
		this.vehicleRegNumber = vehicleRegNumber;
	}
	public String getCarCompany() {
		return carCompany;
	}
	public void setCarCompany(String carCompany) {
		this.carCompany = carCompany;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public Double getInsuredDeclaredValue() {
		return insuredDeclaredValue;
	}
	public void setInsuredDeclaredValue(Double insuredDeclaredValue) {
		this.insuredDeclaredValue = insuredDeclaredValue;
	}
	public String getTypeOfCover() {
		return typeOfCover;
	}
	public void setTypeOfCover(String typeOfCover) {
		this.typeOfCover = typeOfCover;
	}
	public Boolean getNoClaimBonusEligble() {
		return noClaimBonusEligble;
	}
	public void setNoClaimBonusEligble(Boolean noClaimBonusEligble) {
		this.noClaimBonusEligble = noClaimBonusEligble;
	}
}
