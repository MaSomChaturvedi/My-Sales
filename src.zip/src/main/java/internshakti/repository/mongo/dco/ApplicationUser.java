package internshakti.repository.mongo.dco;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.bson.types.Binary;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

public class ApplicationUser {
	@Id
	private String id;

	private String email;

	private String mobile;

	private String name;

	private String token;

	private Role role;

	private String empId;

	private ApplicationUser parentUser;

	private String otp;
	
	public String dob;
    public String state;
    public String nominee;
    public String relation;
    public String age;
    public String pin;
    public String address;
    public String confirmpassword;   
	private Date otpGeneratedTime;

	private List<ApplicationUser> childs;

	private List<ApplicationUser> parents;
	public Binary  agentPhoto;
    public Binary  agentPanCard;
    public Binary  agentAddressProf1;
    public Binary  agentAddressProf2;
    public Binary  agencyPhoto;
    public Binary  agencyPanCard;
    public Binary  agencyAddressProf1;
    public Binary  agencyAddressProf2;
    public Binary  companyGst;
    public Binary  companyCoi;
	
	public ApplicationUser(String id) {
		super();
		this.id = id;
	}

	public ApplicationUser() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public ApplicationUser getParentUser() {
		return parentUser;
	}

	public void setParentUser(ApplicationUser parentUser) {
		this.parentUser = parentUser;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public Date getOtpGeneratedTime() {
		return otpGeneratedTime;
	}

	public void setOtpGeneratedTime(Date otpGeneratedTime) {
		this.otpGeneratedTime = otpGeneratedTime;
	}

	public boolean shouldAgainSendOTP() {
		if (otpGeneratedTime == null) {
			return true;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(otpGeneratedTime);
		calendar.add(Calendar.MINUTE, 5);
		return calendar.getTime().before(new Date());
	}

	public boolean validOTP() {
		if (otpGeneratedTime == null || otp == null) {
			return false;
		}
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(otpGeneratedTime);
		calendar.add(Calendar.HOUR, 5);
		return calendar.getTime().after(new Date());
	}

	public Date createdTime() {
		return new ObjectId(id).getDate();
	}

	public enum Role {
		ROLE_CUSTOMER, ROLE_EMPLOYEE, ROLE_ADMIN;
		public static String[] getRoles() {
			String[] roles = new String[Role.values().length];
			int i = 0;
			for (Role role : Role.values()) {
				roles[i] = role.name();
				i++;
			}
			return roles;
		}
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public List<ApplicationUser> getChilds() {
		return childs;
	}

	public void setChilds(List<ApplicationUser> childs) {
		this.childs = childs;
	}

	public List<ApplicationUser> getParents() {
		return parents;
	}

	public void setParents(List<ApplicationUser> parents) {
		this.parents = parents;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getNominee() {
		return nominee;
	}

	public void setNominee(String nominee) {
		this.nominee = nominee;
	}

	public String getRelation() {
		return relation;
	}

	public void setRelation(String relation) {
		this.relation = relation;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmPassword) {
		this.confirmpassword = confirmPassword;
	}

	public Binary getAgentPhoto() {
		return agentPhoto;
	}

	public void setAgentPhoto(Binary agentPhoto) {
		this.agentPhoto = agentPhoto;
	}

	public Binary getAgentPanCard() {
		return agentPanCard;
	}

	public void setAgentPanCard(Binary agentPanCard) {
		this.agentPanCard = agentPanCard;
	}

	public Binary getAgentAddressProf1() {
		return agentAddressProf1;
	}

	public void setAgentAddressProf1(Binary agentAddressProf1) {
		this.agentAddressProf1 = agentAddressProf1;
	}

	public Binary getAgentAddressProf2() {
		return agentAddressProf2;
	}

	public void setAgentAddressProf2(Binary agentAddressProf2) {
		this.agentAddressProf2 = agentAddressProf2;
	}

	public Binary getAgencyPhoto() {
		return agencyPhoto;
	}

	public void setAgencyPhoto(Binary agencyPhoto) {
		this.agencyPhoto = agencyPhoto;
	}

	public Binary getAgencyPanCard() {
		return agencyPanCard;
	}

	public void setAgencyPanCard(Binary agencyPanCard) {
		this.agencyPanCard = agencyPanCard;
	}

	public Binary getAgencyAddressProf1() {
		return agencyAddressProf1;
	}

	public void setAgencyAddressProf1(Binary agencyAddressProf1) {
		this.agencyAddressProf1 = agencyAddressProf1;
	}

	public Binary getAgencyAddressProf2() {
		return agencyAddressProf2;
	}

	public void setAgencyAddressProf2(Binary agencyAddressProf2) {
		this.agencyAddressProf2 = agencyAddressProf2;
	}

	public Binary getCompanyGst() {
		return companyGst;
	}

	public void setCompanyGst(Binary companyGst) {
		this.companyGst = companyGst;
	}

	public Binary getCompanyCoi() {
		return companyCoi;
	}

	public void setCompanyCoi(Binary companyCoi) {
		this.companyCoi = companyCoi;
	}

	
}
