package internshakti.repository.mongo.dco;

import org.springframework.data.annotation.Id;

public class LeadGeneration {
	@Id
	private String id;
	private String name;
	private String mobile;
	private String age;
	private String productType;
	private ApplicationUser leadGenerator;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public ApplicationUser getLeadGenerator() {
		return leadGenerator;
	}
	public void setLeadGenerator(ApplicationUser leadGenerator) {
		this.leadGenerator = leadGenerator;
	}
	
	
}
